# TODO: Switch to Cloudflare Tunnel for Live Testing

- [x] Modify run.py to replace ngrok with Cloudflare Tunnel setup
- [x] Add code to create 'glory2yahpub-tunnel' if it doesn't exist
- [x] Update tunnel running logic to parse Cloudflare output for public URL
- [x] Keep URL testing and Flask app running logic
- [ ] Test the modified run.py to ensure tunnel works and app is accessible
